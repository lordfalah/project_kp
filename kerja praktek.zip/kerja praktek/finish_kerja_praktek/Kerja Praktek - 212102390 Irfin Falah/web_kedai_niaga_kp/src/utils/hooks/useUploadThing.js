import { useState } from "react";
import { DANGEROUS__uploadFiles } from "uploadthing/client";
import { useEvent } from "./useEvent";
import useFetch from "./useFetch";

const useEndpointMetadata = (endpoint) => {
  const { data } = useFetch("/api/uploadthing");

  return data?.find((x) => x.slug === endpoint);
};

export const useUploadThing = ({
  endpoint,
  onClientUploadComplete,
  onUploadError,
}) => {
  const [isUploading, setUploading] = useState(false);

  const permittedFileInfo = useEndpointMetadata(endpoint);

  const startUpload = useEvent(async (files) => {
    setUploading(true);
    try {
      const res = await DANGEROUS__uploadFiles(files, endpoint);
      setUploading(false);
      onClientUploadComplete?.(res);
      return res;
    } catch (e) {
      setUploading(false);
      onUploadError?.(e);
      return;
    }
  });

  return {
    startUpload,
    isUploading,
    permittedFileInfo,
  };
};

export const generateReactHelpers = () => {
  return {
    useUploadThing,
    uploadFiles: DANGEROUS__uploadFiles,
  };
};

export const FullFile = {
  file: File,
  contents: String,
};
